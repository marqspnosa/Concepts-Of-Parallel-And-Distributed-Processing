import java.util.Random;

public class TeleGame {
    public static void main(String[] args) {
        int numOfPlayers = Integer.parseInt(args[0]);
        String[] msg = new String[args.length - 1];
        for (int i = 1; i < args.length; i++) {
            msg[i - 1] = args[i];
        }
        Player[] players = new Player[numOfPlayers];
        for (int i = 0; i < numOfPlayers; i++) {
            players[i] = new Player(i + 1);
        }

        players[0].receiveMessage(msg, players, 1);
    }
}
class Player {
    private final int playerNum;

    public Player(int playerNum) {
        this.playerNum = playerNum;
    }

    public void receiveMessage(String[] msg, Player[] players, int nextPlayerIndex) {
        
        swapWords(msg);

        System.out.println("Player " + playerNum + " received: " + String.join(" ", msg));

        
        if (nextPlayerIndex < players.length) {
            players[nextPlayerIndex].receiveMessage(msg, players, nextPlayerIndex + 1);
        } else {
          
            System.out.println("Final message from Player " + playerNum + ": " + String.join(" ", msg));
        }
    }

    private void swapWords(String[] msg) {
        Random random = new Random();
        int index1 = random.nextInt(msg.length);
        int index2;

        do {
            index2 = random.nextInt(msg.length);
        } while (index1 == index2);

        
        String temp = msg[index1];
        msg[index1] = msg[index2];
        msg[index2] = temp;
    }
}