import java.util.Random;

public class HorseRace {
    private static final int MAX_HORSES = 5;
    private static final int MIN_HORSES = 2;
    private static final int FINISH_LINE = 100;

    public static void main(String[] args) {
        int horseCount = parseHorseCount(args);
        Horse[] horses = new Horse[horseCount];
        Thread[] threads = new Thread[horseCount];

        for (int i = 0; i < horseCount; i++) {
            horses[i] = new Horse(i + 1);
            threads[i] = new Thread(horses[i]);
            threads[i].start();
        }

        for (int i = 0; i < horseCount; i++) {
            try {
                threads[i].join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private static int parseHorseCount(String[] args) {
        if (args.length == 0) {
            return 2;
        }
        try {
            int count = Integer.parseInt(args[0]);
            if (count < MIN_HORSES || count > MAX_HORSES) {
                return 2;
            }
            return count;
        } catch (NumberFormatException e) {
            return 2;
        }
    }

    static class Horse implements Runnable {
        private final int id;
        private int distanceCovered = 0;
        private final Random generator = new Random();

        public Horse(int id) {
            this.id = id;
        }

        @Override
        public void run() {
            while (distanceCovered < FINISH_LINE) {
                int strideDistance = (generator.nextInt(5)) + 6;
                distanceCovered += strideDistance;
                System.out.println("Horse #" + id + ": " + distanceCovered);
                try {
                    Thread.sleep(100); 
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        }
    }
}